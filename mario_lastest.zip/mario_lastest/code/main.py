import pygame, sys
from settings import *
from level import Level
from game_data import *
from overworld import Overworld
from menu import *
from ui import UI
class Game:
    def __init__(self):
        self.lastTime = 0
        self.interval = 250 

        #game attributes
        self.max_level = 0
        self.max_health = 100
        self.cur_health = 100
        self.coins = 0

        
        #audio
        self.bg_music = pygame.mixer.Sound('../audio/theme.wav')
        self.stage_music = pygame.mixer.Sound('../audio/level.wav')

        #UI
        self.ui = UI(screen)

        self.main_menu = MainMenu(self)
        self.control = ControlMenu(self)
        self.curr_menu = self.main_menu
        self.overworld = Overworld(0,self.max_level,screen,self.create_level,self.stage_music,self.bg_music)
        self.status = 'menu'


        self.bg_music.play(loops = -1)
        self.bg_music.set_volume(0.5)

    def create_level(self,current_level):
        self.level = Level(current_level,screen,self.create_overworld, self.change_coins, self.change_health, self.reset, self.stage_music)
        self.status = 'level'
        

    def create_overworld(self,current_level,new_max_level):
        if new_max_level > self.max_level:
            self.max_level = new_max_level
        self.overworld = Overworld(current_level,self.max_level,screen,self.create_level,self.stage_music,self.bg_music)
        self.status = 'overworld'
        self.bg_music.play(loops = -1)

    def change_coins(self, amount, test):
        self.coins += amount
        if test == 1:
            return self.coins

    def change_health(self, amount):
        self.cur_health += amount

    def check_game_over(self):
        if self.cur_health <= 0:
            self.reset()
            self.overworld = Overworld(0 ,self.max_level,screen,self.create_level,self.stage_music,self.bg_music)
            #self.stage_music.stop()
            self.status = 'overworld'
            self.bg_music.play()
            


    def reset(self):
        self.cur_health = 100
        self.coins = 0

    def draw_text(self, text, size, x, y ):
        font = pygame.font.Font(None,size)
        text_surf = font.render(text, True, 'white')
        text_rect = text_surf.get_rect()
        text_rect.center = (x,y)
        screen.blit(text_surf,text_rect)     

    def run(self):
        if self.status == 'overworld':
            self.overworld.run()
            if self.overworld.run() == 'menu':
                self.status = 'menu'
        else:
            self.level.run()
            self.ui.show_health(self.cur_health, self.max_health)
            self.ui.show_coins(self.coins)
            self.check_game_over()

pygame.init()
screen = pygame.display.set_mode((screen_width,screen_height))
clock = pygame.time.Clock()
game = Game()

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    screen.fill('gray')
    if game.status == 'menu':
        game.curr_menu.display_menu()
    else:
        game.run()

    pygame.display.update()
    clock.tick(60)