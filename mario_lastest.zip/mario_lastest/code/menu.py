import pygame
from settings import screen_width, screen_height


class Menu():
    def __init__(self,game):
        
        self.game = game
        self.mid_w, self.mid_h = screen_width / 2, screen_height / 2
        self.cursor_rect = pygame.Rect(0,0,50,50)
        self.offset = - 150

    def draw_cursor(self):
        self.game.draw_text('*', 50, self.cursor_rect.x, self.cursor_rect.y)

class MainMenu(Menu):
    def __init__(self,game):
        Menu.__init__(self,game) 
        self.state = "Start"
        self.startx, self.starty = self.mid_w, self.mid_h
        self.optionsx, self.optionsy = self.mid_w, self.mid_h + 50
        self.creditsx, self.creditsy = self.mid_w, self.mid_h + 100
        self.cursor_rect.midtop = (self.startx + self.offset, self.starty)
        self.select_sound = pygame.mixer.Sound('../audio/ui/select.wav')

    def display_menu(self):
        self.check_input()
        self.game.draw_text("Muhummud The best CPE", 100, screen_width / 2, screen_height / 2 - 150)
        self.game.draw_text("Start Game", 80, self.startx, self.starty)
        self.game.draw_text("Control", 80, self.optionsx, self.optionsy)
        self.game.draw_text("Exit", 80, self.creditsx, self.creditsy)
        self.draw_cursor()

    def move_cursor(self):
        keys = pygame.key.get_pressed()
        if (keys[pygame.K_DOWN] or keys[pygame.K_s])  and (pygame.time.get_ticks() > self.game.lastTime + self.game.interval):
            self.select_sound.play()
            if self.state == 'Start':
                self.cursor_rect.midtop = (self.optionsx + self.offset, self.optionsy)
                self.state = 'Control'
            elif self.state == 'Control':
                self.cursor_rect.midtop = (self.creditsx + self.offset, self.creditsy)
                self.state = 'Exit'
            elif self.state == 'Exit':
                self.cursor_rect.midtop = (self.startx + self.offset, self.starty)
                self.state = 'Start'
            self.game.lastTime = pygame.time.get_ticks()
        elif (keys[pygame.K_UP] or keys[pygame.K_w]) and (pygame.time.get_ticks() > self.game.lastTime + self.game.interval):
            self.select_sound.play()
            if self.state == 'Start':
                self.cursor_rect.midtop = (self.creditsx + self.offset, self.creditsy)
                self.state = 'Exit'
            elif self.state == 'Control':
                self.cursor_rect.midtop = (self.startx + self.offset, self.starty)
                self.state = 'Start'
            elif self.state == 'Exit':
                self.cursor_rect.midtop = (self.optionsx + self.offset, self.optionsy)
                self.state = 'Control'
            self.game.lastTime = pygame.time.get_ticks() 

    def check_input(self):
        keys = pygame.key.get_pressed()
        self.move_cursor()
        if keys[pygame.K_RETURN] and (pygame.time.get_ticks() > self.game.lastTime + self.game.interval):
            self.select_sound.play()
            if self.state == 'Start':
                self.game.status = 'overworld'
            elif self.state == 'Control':
                self.game.curr_menu = self.game.control
                pass
            elif self.state == 'Exit':
                pygame.quit()
            self.game.lastTime = pygame.time.get_ticks() 

class ControlMenu(Menu):
    def __init__(self, game):
        Menu.__init__(self, game)
        self.select_sound = pygame.mixer.Sound('../audio/ui/select.wav')

    def display_menu(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_BACKSPACE]:
            self.select_sound.play()
            self.game.curr_menu = self.game.main_menu
            print('self.game.curr_menu')
        self.game.lastTime = pygame.time.get_ticks() 
        self.game.draw_text('Credits', 20, screen_width / 2, screen_height / 2 - 20)
        self.game.draw_text('Made by me', 15, screen_width / 2, screen_height / 2 + 10)   
        pygame.display.update()