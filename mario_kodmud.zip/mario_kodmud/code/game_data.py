level_try = {
        'terrain': '../levels/try/try_terrain.csv',
        'player': '../levels/try/try_character.csv',
        'node_pos': (150,400), 
        'unlock':1,
        'node_graphics' : '../graphics/overworld/0'
}

level_try2 = {
        'terrain': '../levels/try/try2_terrain.csv',
        'player': '../levels/try/try2_character.csv',
        'node_pos': (610,220), 
        'unlock':2,
        'node_graphics' : '../graphics/overworld/1'
}

level_try3 = {
        'terrain': '../levels/try/try3_terrain.csv',
        'player': '../levels/try/try3_character.csv',
        'node_pos': (1050,350), 
        'unlock':2,
        'node_graphics' : '../graphics/overworld/2'
}

levels = {
    0: level_try,
    1: level_try2,
    2: level_try3
}