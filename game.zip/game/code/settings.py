'''
level_map = [
'  P                                                    ',
'                                                       ',
'                                                       ',
'        XXX            XX                              ',
'                                                     XX',
'  XXXX         XX           X                        XX',
'  XXXX       XX                               XXX    XX',
'  X     X  XXXX    XX  XX      X    X    X           XX',
'        X  XXXXX   XX  XXX     X    X    X           XX',
'     XXXX  XXXXXX  XX  XXXX    X    X    X           XX',
'XXXXXXXXX  XXXXXX  XX  XXXX    X    X    X           XX']
'''
vertical_tile_number = 11
tile_size = 64
screen_width = 1200
screen_height = vertical_tile_number * tile_size

