import pygame, sys
from settings import *
from level import Level
from game_data import *
from overworld import Overworld
from menu import *
class Game:
    def __init__(self):
        self.lastTime = 0
        self.interval = 250 
        self.max_level = 0
        self.main_menu = MainMenu(self)
        self.control = ControlMenu(self)
        self.curr_menu = self.main_menu
        self.overworld = Overworld(0,self.max_level,screen,self.create_level)
        self.status = 'menu'

    def create_level(self,current_level):
        self.level = Level(current_level,screen,self.create_overworld)
        self.status = 'level'

    def create_overworld(self,current_level,new_max_level):
        if new_max_level > self.max_level:
            self.max_level = new_max_level
        self.overworld = Overworld(current_level,self.max_level,screen,self.create_level)
        self.status = 'overworld'

    def draw_text(self, text, size, x, y ):
        font = pygame.font.Font(None,size)
        text_surf = font.render(text, True, 'white')
        text_rect = text_surf.get_rect()
        text_rect.center = (x,y)
        screen.blit(text_surf,text_rect)     

    def run(self):
        if self.status == 'overworld':
            self.overworld.run()
            if self.overworld.run() == 'menu':
                self.status = 'menu'
        else:
            self.level.run()

pygame.init()
screen = pygame.display.set_mode((screen_width,screen_height))
clock = pygame.time.Clock()
game = Game()

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    screen.fill('black')
    if game.status == 'menu':
        game.curr_menu.display_menu()
    else:
        game.run()

    pygame.display.update()
    clock.tick(60)